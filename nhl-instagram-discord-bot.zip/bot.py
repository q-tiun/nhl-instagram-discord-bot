import json
import os
import time
from datetime import datetime, timezone
from pathlib import Path

import instaloader
from discord_webhook import DiscordWebhook, DiscordEmbed
from dotenv import load_dotenv

load_dotenv()

WEBHOOK_URL = os.environ["DISCORD_WEBHOOK_URL"]
POLL_SECONDS = max(15, int(os.getenv("POLL_SECONDS", "30")))
STATE_FILE = Path(os.getenv("STATE_FILE", "state.json"))
PLAYERS_FILE = Path("players.json")

loader = instaloader.Instaloader(
    download_pictures=False,
    download_videos=False,
    download_video_thumbnails=False,
    download_geotags=False,
    save_metadata=False,
    compress_json=False,
    quiet=True,
)

def load_players():
    return json.loads(PLAYERS_FILE.read_text(encoding="utf-8"))

def load_state():
    if not STATE_FILE.exists():
        return {}
    return json.loads(STATE_FILE.read_text(encoding="utf-8"))

def save_state(state):
    STATE_FILE.write_text(json.dumps(state, indent=2), encoding="utf-8")

def send_alert(player, post):
    webhook = DiscordWebhook(url=WEBHOOK_URL, username="NHL Instagram Alerts")
    embed = DiscordEmbed(
        title=f"{player['name']} posted on Instagram",
        description=(post.caption[:1000] if post.caption else "New Instagram post"),
        url=f"https://www.instagram.com/p/{post.shortcode}/",
        color="2f3136",
    )
    embed.set_footer(text=f"@{player['instagram']} • Instagram")
    if post.date_utc:
        embed.set_timestamp(post.date_utc.replace(tzinfo=timezone.utc))
    webhook.add_embed(embed)
    webhook.execute()

def get_latest_post(username):
    profile = instaloader.Profile.from_username(loader.context, username)
    # Instagram feed posts only. Reels are filtered by is_video; Stories are never read.
    for post in profile.get_posts():
        if post.is_video:
            continue
        return post
    return None

def main():
    players = load_players()
    state = load_state()

    print(f"Monitoring {len(players)} Instagram accounts every {POLL_SECONDS}s.")

    # Prime state on first run so old posts don't flood Discord.
    first_run = not bool(state)
    if first_run:
        for player in players:
            try:
                post = get_latest_post(player["instagram"])
                if post:
                    state[player["instagram"]] = post.shortcode
            except Exception as exc:
                print(f"[prime] @{player['instagram']}: {exc}")
        save_state(state)
        print("Initial state saved. New posts will trigger alerts.")
    while True:
        for player in load_players():
            username = player["instagram"]
            try:
                post = get_latest_post(username)
                if not post:
                    continue

                previous = state.get(username)
                if previous and previous != post.shortcode:
                    send_alert(player, post)
                    print(f"[ALERT] {player['name']} -> {post.shortcode}")

                state[username] = post.shortcode
                save_state(state)
            except Exception as exc:
                print(f"[check] @{username}: {exc}")

        time.sleep(POLL_SECONDS)

if __name__ == "__main__":
    main()
