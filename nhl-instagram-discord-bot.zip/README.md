# NHL Instagram → Discord Bot

Posts-only Instagram monitor for active NHL players.

## Architecture
Instagram public-profile provider → dedupe store → Discord webhook.

The provider is intentionally separated so it can be swapped if Instagram changes access rules.

## Setup
1. Install Python 3.11+.
2. `pip install -r requirements.txt`
3. Copy `.env.example` to `.env`.
4. Put your Discord webhook URL in `DISCORD_WEBHOOK_URL`.
5. Add Instagram handles to `players.json`.
6. Run `python bot.py`.

The default polling interval is 30 seconds. Lower intervals can increase the chance of rate limits or blocks, so don't assume "instant" is guaranteed.

## Important
Instagram's official API does not provide a general real-time webhook for arbitrary player accounts. This project therefore uses a pluggable public-data provider. The default provider uses Instaloader and may be affected by Instagram changes/rate limits. It does not attempt to bypass login checks, CAPTCHAs, or other access controls.

## Alert behavior
- Feed posts only
- Reels/Stories ignored
- Duplicate post IDs are ignored
- Discord embed includes player, timestamp, caption, and Instagram link
